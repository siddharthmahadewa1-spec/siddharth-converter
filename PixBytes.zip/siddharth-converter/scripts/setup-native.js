// Run AFTER "npx cap add android" / "npx cap add ios". Adds the "save to file manager" native code.
const fs = require('fs'), path = require('path');
const pkg = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8')).appId;

if (fs.existsSync('android')) {
  const dir = path.join('android/app/src/main/java', ...pkg.split('.'));
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'DownloadSaverPlugin.java'), `package ${pkg};

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;

@CapacitorPlugin(name = "DownloadSaver")
public class DownloadSaverPlugin extends Plugin {
  @PluginMethod
  public void save(PluginCall call) {
    String name = call.getString("name");
    String data = call.getString("data");
    String mime = call.getString("mime", "application/octet-stream");
    String folder = call.getString("folder", "SiddharthConverter");
    if (name == null || data == null) { call.reject("Missing name or data"); return; }
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) { call.reject("Needs Android 10 or newer"); return; }
    try {
      byte[] bytes = Base64.decode(data, Base64.DEFAULT);
      ContentResolver resolver = getContext().getContentResolver();
      ContentValues values = new ContentValues();
      values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
      values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
      values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + folder);
      // Same name again: replace our old file instead of creating "name (1)".
      try {
        resolver.delete(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
          MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
          new String[]{name, Environment.DIRECTORY_DOWNLOADS + "/" + folder + "/"});
      } catch (Exception ignored) { }
      Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
      if (uri == null) throw new Exception("Could not create the file");
      try (OutputStream os = resolver.openOutputStream(uri)) { os.write(bytes); }
      JSObject res = new JSObject();
      res.put("path", "Downloads/" + folder);
      call.resolve(res);
    } catch (Exception e) {
      call.reject(String.valueOf(e.getMessage()));
    }
  }
}
`);
  fs.writeFileSync(path.join(dir, 'MainActivity.java'), `package ${pkg};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(DownloadSaverPlugin.class);
    super.onCreate(savedInstanceState);
  }

  // No zoom: ignore the phone's font-size setting and pinch / double-tap zoom.
  @Override
  public void onStart() {
    super.onStart();
    if (getBridge() != null && getBridge().getWebView() != null) {
      getBridge().getWebView().getSettings().setTextZoom(100);
      getBridge().getWebView().getSettings().setSupportZoom(false);
      getBridge().getWebView().getSettings().setBuiltInZoomControls(false);
    }
  }
}
`);
  console.log('Android: file-manager saver added.');
}

const plist = 'ios/App/App/Info.plist';
if (fs.existsSync(plist)) {
  let s = fs.readFileSync(plist, 'utf8');
  if (!s.includes('UIFileSharingEnabled')) {
    s = s.replace(/<\/dict>\s*<\/plist>/, '\t<key>UIFileSharingEnabled</key>\n\t<true/>\n\t<key>LSSupportsOpeningDocumentsInPlace</key>\n\t<true/>\n</dict>\n</plist>');
    fs.writeFileSync(plist, s);
  }
  console.log('iOS: Files app access enabled.');
}

// ---- App version (shown in Android app info / iOS settings) ----
const VERSION_NAME = '4.0', VERSION_CODE = 4;

const gradleFiles = ['android/app/build.gradle', 'android/app/build.gradle.kts'].filter((f) => fs.existsSync(f));
for (const f of gradleFiles) {
  let g = fs.readFileSync(f, 'utf8');
  g = g.replace(/(versionCode\s*=?\s*)\d+/, (m, a) => a + VERSION_CODE)
       .replace(/(versionName\s*=?\s*)"[^"]*"/, (m, a) => a + '"' + VERSION_NAME + '"');
  fs.writeFileSync(f, g);
  console.log('Android: version set to ' + VERSION_NAME + ' (code ' + VERSION_CODE + ') in ' + f);
}
if (fs.existsSync('android') && !gradleFiles.length) console.log('WARNING: android/app/build.gradle not found, version not set.');

const pbx = 'ios/App/App.xcodeproj/project.pbxproj';
if (fs.existsSync(pbx)) {
  let x = fs.readFileSync(pbx, 'utf8');
  x = x.replace(/MARKETING_VERSION = [^;]+;/g, 'MARKETING_VERSION = ' + VERSION_NAME + ';')
       .replace(/CURRENT_PROJECT_VERSION = [^;]+;/g, 'CURRENT_PROJECT_VERSION = ' + VERSION_CODE + ';');
  fs.writeFileSync(pbx, x);
  console.log('iOS: version set to ' + VERSION_NAME);
}

// ---- No white flash on launch: dark window background + splash colour ----
const resDir = 'android/app/src/main/res/values';
if (fs.existsSync(resDir)) {
  fs.writeFileSync(resDir + '/siddharth_colors.xml',
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="siddharth_navy">#070B1F</color>\n</resources>\n');
  const stylesPath = resDir + '/styles.xml';
  if (fs.existsSync(stylesPath)) {
    let st = fs.readFileSync(stylesPath, 'utf8');
    st = st.replace(/<style\s+name="(AppTheme(?:\.NoActionBar(?:Launch)?)?)"([^>]*)>([\s\S]*?)<\/style>/g, (whole, name, attrs, body) => {
      let add = '';
      if (!/android:windowBackground/.test(body)) add += '\n        <item name="android:windowBackground">@color/siddharth_navy</item>';
      if (/SplashScreen/.test(attrs) && !/windowSplashScreenBackground/.test(body)) add += '\n        <item name="windowSplashScreenBackground">@color/siddharth_navy</item>';
      return '<style name="' + name + '"' + attrs + '>' + add + body + '</style>';
    });
    fs.writeFileSync(stylesPath, st);
    console.log('Android: dark launch background applied.');
  } else console.log('WARNING: styles.xml not found, launch background not set.');
}
