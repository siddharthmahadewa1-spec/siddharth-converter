SIDDHARTH CONVERTER - build steps (Android + iOS)

Chahiye: Node.js (latest LTS), Android Studio (Android build ke liye), Mac + Xcode (sirf iOS ke liye).

1. npm install
2. npx cap add android          (Mac par: npx cap add ios bhi)
3. npx capacitor-assets generate   (assets/ folder se icon + splash banata hai)
4. npx cap sync
5. npx cap open android  ->  Android Studio me Build > Build APK
   npx cap open ios      ->  Xcode me Run / Archive

Apna logo lagane ke liye:
- www/logo.png        (app ke andar header me, square 512x512)
- assets/icon-only.png (app icon, 1024x1024, bina rounded corners)
Dono replace karo, phir step 3 aur 4 dobara chalao.

App ka naam badalna ho to capacitor.config.json me appName / appId badlo.
Latest Capacitor Android 16 (API 36) ko target karta hai, edge-to-edge UI already handle hai.
