SIDDHARTH CONVERTER - build steps (Android + iOS)

Chahiye: Node.js (latest LTS), Android Studio (Android), Mac + Xcode (sirf iOS).

1. npm install
2. npx cap add android          (Mac par: npx cap add ios bhi)
3. npm run native               (file manager me auto-save wala native code add karta hai)
4. npx capacitor-assets generate (assets/ se icon + splash)
5. npx cap sync
6. npx cap open android -> Build > Generate Signed Bundle / APK (release)
   npx cap open ios     -> Xcode me Run / Archive

Files kahan save hoti hain:
- Android: Downloads/SiddharthConverter (Files / My Files app me dikhega)
- iOS: Files app > On My iPhone > Siddharth Converter > SiddharthConverter

Logo: www/logo.png (512 px) aur assets/icon-only.png (1024 px) replace karo, phir step 4 aur 5 dobara.
Naam badalna ho to capacitor.config.json me appName badlo (appId badla to step 3 dobara chalao).
