PIXBYTES (made by Siddharth) - build steps (Android + iOS)

Needs: Node.js (latest LTS), Android Studio (Android), Mac + Xcode (iOS only).

1. npm install
2. npx cap add android          (on a Mac also: npx cap add ios)
3. npm run native               (adds the native code that saves files to the file manager)
4. npx capacitor-assets generate (icon + splash from assets/)
5. npx cap sync
6. npx cap open android -> Build > Generate Signed Bundle / APK (release)
   npx cap open ios     -> Run / Archive in Xcode

Where files are saved:
- Android: Downloads/SiddharthConverter (shows in the Files / My Files app)
- iOS: Files app > On My iPhone > PixBytes > SiddharthConverter

Logo: www/logo.png (512 px) and assets/icon-only.png (1024 px): replace them, then repeat steps 4 and 5.
To rename the app, change appName in capacitor.config.json (if appId changes, run step 3 again).
