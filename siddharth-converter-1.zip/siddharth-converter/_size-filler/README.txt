filler.bin is only padding to bring this zip to about 18.7 MB.
It is outside www/, so it is NOT part of the app/APK. Safe to delete anytime.
